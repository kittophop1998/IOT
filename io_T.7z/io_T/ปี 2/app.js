const bodyParser = require('body-parser')
const request = require('request')
const express = require('express')
const mongoose = require('mongoose')


const app = express()
const port = process.env.PORT || 4000

var Schema = mongoose.Schema
mongoose.Promise = global.Promise
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/Mydb').then(()=>{
  console.log('@@@ Connect Success @@@')
}, ()=>{
  console.log('!!! Fail to connect !!!')
})


const hostname = '127.0.0.1'
const HEADERS = {
	'Content-Type': 'application/json',
	'Authorization': 'Bearer WcmPGWi6J7Z8F6SJMi0+9gAF9wUw7cwPxEjQ9EEhc6Sfe+O9UPcFnRGHf4speBKINPXjZ6WfOqbcSSJJbWNIAzEyIR1+d+rD1NAvCHFt77WTx1WXSjEGwIN1z3VPrx/BI/2J8nLDFS6iD1rW28ytCgdB04t89/1O/w1cDnyilFU='
}

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())


// Push
app.get('/webhook', (req, res) => {
	// push block
	let msg = 'Hello World!'
	push(msg)
	res.send(msg)
})

// Reply
app.post('/webhook', (req, res) => {
	// reply block
	let reply_token = req.body.events[0].replyToken
	let msg = req.body.events[0].message.text
	if(msg == 'hello'){
		reply(reply_token, 'Hi!')
	}else{
		reply(reply_token, msg)
	}
	//reply(reply_token, msg)
})

function push(msg) {
	let body = JSON.stringify({
		// push body
		to: 'U4039fa1eef2d0b03345c0ce8a7bd52b3',
		messages: [
			{
				type: 'text',
				text: msg
			}
		]
	})
	curl('push', body)
}

function reply(reply_token, msg) {
	let body = JSON.stringify({
		// reply body
		replyToken: reply_token,
		messages: [
			{
				type: 'text',
				text: msg
			}
		]
	})
	curl('reply', body);
}

function curl(method, body) {
	request.post({
		url: 'https://api.line.me/v2/bot/message/' + method,
		headers: HEADERS,
		body: body
	}, (err, res, body) => {
		console.log('status = ' + res.statusCode)
	})
}

app.listen(port, hostname, () => {
	console.log(`Server running at http://${hostname}:${port}/`)
})

/*----------------------------------------------------------------------------*/

var dataSchema = new Schema({
	id:{type:String, required:true, unique:true},
	val:{type:String,  unique:true, required:true}
})


const date = Date.now(); 

var DB_table = new Schema ({
	id:{type:String, required:true, unique:true},
	temp:{type:Number, required:true},
	humi:{type:Number, required:true,},
	water:{type:String, required:true,},
	dust:{type:Object, required:true},
	date:{type:String,required:true}
	
})



var data = mongoose.model('data', dataSchema)
var DB_t = mongoose.model('DB',DB_table)


app.post("/post", (req, res) => {
	DB_t.find().then(doc => {
	  let time = req.body.DevEUI_uplink.Time;
	  let posT = time.search("T");
	  let hex2str = hex_to_ascii(req.body.DevEUI_uplink.payload_hex);
	  let buf = new data({
		id: doc.length,
		temp: hex2str.slice(0, hex2str.search("T")),
		humi: hex2str.slice(hex2str.search("T") + 1, hex2str.search("H")),
		water: hex2str.slice(hex2str.search("H") + 1, hex2str.search("W")),
		gas: hex2str.slice(hex2str.search("W") + 1, hex2str.search("G")),
		dust: {
		  d1_0: hex2str.slice(hex2str.search("G") + 1, hex2str.search("D1_0")),
		  d2_5: hex2str.slice(hex2str.search("D1_0") + 4, hex2str.search("D2_5")),
		  d10_0: hex2str.slice(
			hex2str.search("D2_5") + 4,
			hex2str.search("D10_0")
		  )
		},
		date:
		  time.slice(posT - 2, posT) +
		  time.slice(posT - 5, posT - 3) +
		  time.slice(posT - 8, posT - 6) +
		  time.slice(posT + 1, posT + 3) +
		  time.slice(posT + 4, posT + 6) +
		  time.slice(posT + 7, posT + 9)
	  });
	  buf.save().then(
		doc => {
		  res.send("save to db\n" + doc);
		},
		e => {
		  res.status(400).send("can not save to database\n" + e);
		}
	  );
	});
  });

app.post('/post',function(req,res){
	let buf = new DB_t({
		id:req.body.id,
		temp:req.body.temp,	
		humi:req.body.humi,
		water:req.body.water,
		gas:req.body.gas
		
	
	})
	buf.save().then(function(docs){
		res.send(docs)
	},function(err){
		res.status(404).send(err)
	})
})

app.get('/getall',function(req,res){
	DB_t.find().then(function(docs){
		res.send(docs)
	},function(docs){
		res.status(404).send(err)
	})
})

/*
app.get('/getbtw',function(req,res){
	DB_table.find({date:{$gte:req.params.T_A, $lte:req.params.T_B}}).then(function(docs){
		res.send(docs)
	},function(docs){
		res.status(404).send(err)
	})
})*/

/*
app.get('/get',function(req,res){
	stdDB.find().then(function(docs){
		res.send(docs)
	},function(docs){
		res.status(404).send(err)	
	})
})

/*
app.get('/:input', (req,res)=>{
	res.send(req.params.input)
})
*/
app.get('/getdel',function(req,res){
	DB_t.remove({},function(docs){
		res.send(docs)
	},function(docs){
		res.send(err)
	})
})


/*การค้นหา โดยระบุ ชื่อ*/ 
app.get('/geteq', function(req,res){
	stdDB.find({id:{$eq:req.params.input}}).then(function(docs){
		res.send(docs)
	},function(docs){
		res.status(404).send(err)
	})
})

app.get('/getalldata',(req,res)=>{
	data.find().then((docs)=>{
		res.send(docs)
	})
})

app.get('/postdata', (req,res)=>{
	let buffer = new data({
		name : req.body.name,
		year : req.body.year
	})
	buffer.save().then((docs)=>{
		res.send(docs)
	})
})







